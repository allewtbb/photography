import { useQuery } from "@tanstack/react-query";
import MasonryGrid from "@/components/MasonryGrid";
import type { Collection, Photo } from "@shared/schema";

export default function Home() {
  const { data: allPhotos = [] } = useQuery<Photo[]>({
    queryKey: ["/api/photos"],
  });

  const photos = allPhotos.map((photo) => ({
    id: photo.id,
    src: photo.imageUrl,
    alt: photo.alt,
  }));

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="mb-12">
          <h1 className="text-5xl lg:text-6xl font-light tracking-tighter mb-4">
            Fine Art Photography
          </h1>
          <p className="text-muted-foreground text-lg font-light max-w-2xl">
            Capturing moments of beauty through minimalist composition and natural light
          </p>
        </div>

        {photos.length > 0 ? (
          <MasonryGrid photos={photos} />
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              No photos yet. Visit the{" "}
              <a href="/admin" className="underline">
                admin panel
              </a>{" "}
              to add some.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
