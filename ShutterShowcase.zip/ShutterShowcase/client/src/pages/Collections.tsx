import { useQuery } from "@tanstack/react-query";
import CollectionCard from "@/components/CollectionCard";
import type { Collection, Photo } from "@shared/schema";

export default function Collections() {
  const { data: collections = [], isLoading } = useQuery<Collection[]>({
    queryKey: ["/api/collections"],
  });

  const { data: photoCounts = {} } = useQuery<Record<string, number>>({
    queryKey: ["/api/photo-counts"],
    enabled: collections.length > 0,
  });

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="mb-12">
          <h1 className="text-4xl lg:text-5xl font-light tracking-tighter mb-4">
            Collections
          </h1>
          <p className="text-muted-foreground text-lg font-light">
            Curated series of photography exploring different themes and subjects
          </p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading collections...</p>
          </div>
        ) : collections.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {collections.map((collection) => (
              <CollectionCard
                key={collection.id}
                id={collection.id}
                title={collection.title}
                coverImage={collection.coverImageUrl || ""}
                photoCount={photoCounts[collection.id] || 0}
                description={collection.description || ""}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              No collections yet. Visit the{" "}
              <a href="/admin" className="underline">
                admin panel
              </a>{" "}
              to create some.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
