import { Mail, Instagram, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function About() {
  return (
    <div className="min-h-screen">
      <div className="max-w-4xl mx-auto px-6 py-16">
        <h1 className="text-4xl lg:text-5xl font-light tracking-tighter mb-12">
          About
        </h1>

        <div className="space-y-8 text-lg font-light leading-relaxed">
          <p className="text-foreground">
            Welcome to my photography portfolio. I specialize in fine art photography
            with a focus on minimalist compositions, natural light, and capturing
            the essence of landscapes, architecture, and human moments.
          </p>

          <p className="text-muted-foreground">
            Each photograph is carefully composed to emphasize simplicity and beauty,
            drawing inspiration from the natural world and urban environments. My work
            explores the relationship between light, space, and form.
          </p>

          <p className="text-muted-foreground">
            Through my lens, I aim to create images that evoke emotion and invite
            contemplation. Whether it's the quiet majesty of mountain ranges or the
            geometric precision of modern architecture, I seek to find beauty in
            both the grand and the subtle.
          </p>

          <div className="pt-8 border-t border-border">
            <h2 className="text-2xl font-light tracking-tight mb-6">Get in Touch</h2>
            <div className="flex flex-wrap gap-4">
              <Button
                variant="default"
                className="gap-2"
                data-testid="button-contact-email"
                onClick={() => console.log("Email contact triggered")}
              >
                <Mail className="w-4 h-4" />
                Email Me
              </Button>
              <Button
                variant="outline"
                className="gap-2"
                data-testid="button-contact-instagram"
                onClick={() => console.log("Instagram link triggered")}
              >
                <Instagram className="w-4 h-4" />
                Instagram
              </Button>
            </div>
          </div>

          <div className="pt-8">
            <div className="flex items-start gap-4 p-6 rounded-md bg-muted/50">
              <Camera className="w-6 h-6 text-muted-foreground mt-1" />
              <div>
                <h3 className="font-normal tracking-tight mb-2">Print Sales</h3>
                <p className="text-sm text-muted-foreground">
                  Limited edition prints are available for purchase. Contact me for
                  pricing and availability.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
