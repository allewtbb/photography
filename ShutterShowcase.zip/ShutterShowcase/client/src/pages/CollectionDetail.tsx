import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import PhotoGrid from "@/components/PhotoGrid";
import type { Collection, Photo } from "@shared/schema";

export default function CollectionDetail() {
  const [, params] = useRoute("/collection/:id");
  const collectionId = params?.id || "";

  const { data: collection } = useQuery<Collection>({
    queryKey: ["/api/collections", collectionId],
    enabled: !!collectionId,
  });

  const { data: photos = [], isLoading } = useQuery<Photo[]>({
    queryKey: ["/api/collections", collectionId, "photos"],
    enabled: !!collectionId,
  });

  const photoData = photos.map((photo) => ({
    id: photo.id,
    src: photo.imageUrl,
    alt: photo.alt,
    aspectRatio: photo.aspectRatio || undefined,
  }));

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <Link 
          href="/collections" 
          className="inline-flex items-center gap-2 text-muted-foreground hover-elevate active-elevate-2 px-3 py-2 rounded-md mb-8 transition-colors"
          data-testid="link-back-collections"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm font-light">Back to Collections</span>
        </Link>

        <div className="mb-12">
          <h1 className="text-4xl lg:text-5xl font-light tracking-tighter mb-4">
            {collection?.title || "Loading..."}
          </h1>
          <p className="text-muted-foreground text-lg font-light max-w-3xl leading-relaxed">
            {collection?.description || ""}
          </p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading photos...</p>
          </div>
        ) : photoData.length > 0 ? (
          <PhotoGrid photos={photoData} columns={3} />
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No photos in this collection yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
