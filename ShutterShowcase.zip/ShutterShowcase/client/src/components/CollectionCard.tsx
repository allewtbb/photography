import { Link } from "wouter";

type CollectionCardProps = {
  id: string;
  title: string;
  coverImage: string;
  photoCount: number;
  description?: string;
};

export default function CollectionCard({
  id,
  title,
  coverImage,
  photoCount,
  description,
}: CollectionCardProps) {
  return (
    <Link 
      href={`/collection/${id}`} 
      className="group block"
      data-testid={`link-collection-${id}`}
    >
      <div className="relative overflow-hidden rounded-md aspect-video hover-elevate active-elevate-2 transition-all duration-300 hover:scale-[1.02]">
        <img
          src={coverImage}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <h3 className="text-2xl font-light tracking-tight text-white mb-1">
            {title}
          </h3>
          {description && (
            <p className="text-sm text-white/80 mb-2">{description}</p>
          )}
          <p className="text-sm text-white/60">
            {photoCount} {photoCount === 1 ? "photo" : "photos"}
          </p>
        </div>
      </div>
    </Link>
  );
}
