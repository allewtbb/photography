import { useState } from "react";
import { ImageModal } from "./ImageModal";

type Photo = {
  id: string;
  src: string;
  alt: string;
};

type MasonryGridProps = {
  photos: Photo[];
};

export default function MasonryGrid({ photos }: MasonryGridProps) {
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);

  // Distribute photos into columns for masonry layout
  const columns = 3;
  const photoColumns: Photo[][] = Array.from({ length: columns }, () => []);
  
  photos.forEach((photo, index) => {
    photoColumns[index % columns].push(photo);
  });

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {photoColumns.map((columnPhotos, columnIndex) => (
          <div key={columnIndex} className="flex flex-col gap-4">
            {columnPhotos.map((photo) => (
              <button
                key={photo.id}
                onClick={() => setSelectedPhoto(photo)}
                className="group relative overflow-hidden rounded-md hover-elevate active-elevate-2 transition-all duration-300 hover:scale-[1.02]"
                data-testid={`button-photo-${photo.id}`}
              >
                <img
                  src={photo.src}
                  alt={photo.alt}
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
              </button>
            ))}
          </div>
        ))}
      </div>

      <ImageModal
        photo={selectedPhoto}
        onClose={() => setSelectedPhoto(null)}
      />
    </>
  );
}
