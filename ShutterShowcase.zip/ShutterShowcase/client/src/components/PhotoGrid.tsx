import { useState } from "react";
import { ImageModal } from "./ImageModal";

type Photo = {
  id: string;
  src: string;
  alt: string;
  aspectRatio?: string;
};

type PhotoGridProps = {
  photos: Photo[];
  columns?: number;
};

export default function PhotoGrid({ photos, columns = 3 }: PhotoGridProps) {
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);

  return (
    <>
      <div
        className={`grid gap-4 ${
          columns === 2
            ? "grid-cols-1 md:grid-cols-2"
            : columns === 3
            ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
            : "grid-cols-1 md:grid-cols-2 lg:grid-cols-4"
        }`}
      >
        {photos.map((photo) => (
          <button
            key={photo.id}
            onClick={() => setSelectedPhoto(photo)}
            className="group relative overflow-hidden rounded-md hover-elevate active-elevate-2 transition-all duration-300 hover:scale-[1.02]"
            data-testid={`button-photo-${photo.id}`}
          >
            <img
              src={photo.src}
              alt={photo.alt}
              className="w-full h-full object-cover"
              style={{ aspectRatio: photo.aspectRatio || "auto" }}
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
          </button>
        ))}
      </div>

      <ImageModal
        photo={selectedPhoto}
        onClose={() => setSelectedPhoto(null)}
      />
    </>
  );
}
