import { Link, useLocation } from "wouter";
import { Camera } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Collections", href: "/collections" },
    { label: "About", href: "/about" },
    { label: "Admin", href: "/admin" },
  ];

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-sm bg-background/80 border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <Link 
            href="/" 
            className="flex items-center gap-2 hover-elevate active-elevate-2 px-3 py-2 rounded-md transition-colors" 
            data-testid="link-home"
          >
            <Camera className="w-5 h-5" />
            <span className="font-light text-lg tracking-tight">Portfolio</span>
          </Link>

          <div className="flex items-center gap-6">
            {navItems.map((item) => (
              <Link 
                key={item.href} 
                href={item.href}
                className={`text-sm font-light tracking-tight hover-elevate active-elevate-2 px-3 py-2 rounded-md transition-colors ${
                  location === item.href
                    ? "text-foreground"
                    : "text-muted-foreground"
                }`}
                data-testid={`link-${item.label.toLowerCase()}`}
              >
                {item.label}
              </Link>
            ))}
            <ThemeToggle />
          </div>
        </div>
      </div>
    </nav>
  );
}
